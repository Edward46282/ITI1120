#First example 
def maximum(l):
    '''
    Given the list of numbers l, the function returns the maximum number from the list
    '''
    # n = len(l)
    current_max = l[0] #1*1
    for item in l: #1*n
        if item > current_max: #1*n
            current_max = item #1*n
        return current_max #1*1


# operation <= 1 + n + n + n + 1 = 3n +2 = O(n)

# .... 4n - 1000 = 0(n)



# Secon example

def duplicates(l):
    "(list of num) -> bool"

    n=len(l)
    for i in range(n): # 1 * n
        for j in range(n): # 1 * n^2  -> it is n^2 because in first iteration, i = 0*n + second iteration -> i = 1*n
            if l[i] == l[j] and i != j: # 1*n^2
                return True #<==1
    return False # <=1

#<= n + 2n^2 + 1 <= n + n^2 = n^2 + n^2 = 2n^2 = O(n^2) <= it means at most x^2


#more effecient ver.
def duplicates(l):
    "(list of num) -> bool"

    n=len(l)
    for i in range(n): #1 *n
        for j in range(i+1,n): #1 * (n+1)n /2
            if l[i] == l[j]: #we removed the condition where it checks if i is not same as j since the range of j starts at i+1. So, i can't be j
                return True # <=1
    return False  # <=1

#<= n + (n+1)*n +1 = n^2 + 2n + 1 <= n^2 + 2n^2 +1 = 3n^2 + 1 = O(n^2)


##### Explaining why it works:: => for nested for loop. you pick one card. And compare other cards using inner loop. It makes senese r?


#student
def duplicates(l):
    tmp = []
    for i in range(n):
        if l[i] not in tmp:
            tmp.append(l[i])
        else:
            return True
    return False


#sort ver.
def duplicates(l):
    l.sort() #n*log n
    for i in range(n-1): #1*n
        if l[i] ==  l[i+1]: #1*n
            return True #<=1
    return False #<= 1

#this line cost <= ??? + 2n +1 
