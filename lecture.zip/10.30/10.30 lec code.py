def triplicates(l):
    n = len(l) #1
    for i in range(n): #1*n
        for j in range(n): #n*n = n^2
            for k in range(k): #n*n*n = n^3
                if l[i]==l[j] and l[j] == l[k] and i!=j and l!=k and j!=k: #5*n^3
                    return True #<== 1
    return False #<=1

#1 + n + n^2 + 6*n^3 + 1 = 2 + n + n^2 +6*n^3 = O(n^3)
# == 2*n^3 + n^3 + n^3 + 6*n^3 = O(n^3)


#more effecient solution not n^3
def triplicates_via_count(l):
    for item in l: # 1*n
        if l.count(item) >= 3: #n*n = n^2
            return True # <=1
    return False #<= 1

#n + n^2 + 1 = O(n^2)


#more and more effecient soltuion
def triplicates_via_sort(l): 
    n=len(l)#1
    l.sort() #O(n*log n)
    for i in range(n-2): #1*(n-2)
        if l[i]==[i+2]: #1*(n-2)
            return True #<=1
    return False #<= 1


#1 + 2*(n-2) +1 = 2 + 2n - 4 + n*log n = (2n - 2) + (n*log n) = O(n*log n)



#ex
def aha(l,x):
    l[0] = 999
    x = 888

num = 100
t = [l,1,1,]
aha(t,num)
print(num)
print(t)
