#First example
def only_vowes(phrase):
    '''
    (str) -> str
    returns a new string containing all the voes the given string
    >>> only_vowes("August")
    'Auu'
    >>> count_vowes("smrt")
    ''
    '''
    vowels = ""
    for x in phrase:
        if x in 'aeiouAEIOU':
            vowels += x

    return vowels



#second ex
for i in range (1,5):  #the range function will produce 0,1,2,3,4
    print(i)

#2.2

for i in range(10,0,-1): #The number goes down
    print(i)

print("blastoff")


# third question: it prints out every second character

s = "abcde"

for i in range(0,len(s),2):  #0,1,2,3,4 ... len(s) -1
    print(s[i])




#last ex
    #problem:
#write a function called BLA, has one parameter a string s and you need to return a new string


def only_vowes(phrase):
    '''
    (str) -> str
    returns a new string containing all the voes the given string
    >>> only_vowes("August")
    'Auu'
    >>> count_vowes("smrt")
    ''
    '''
    vowels = ""
    for x in phrase:
        if x in 'aeiouAEIOU':
            vowels += x

    return vowels



def flip_consecutive_disjoint_pairs_anddd(s, k):
    '''
    (str, int) -> str
    precondition: k>= 1
    >>>flip_consecutive_disjoint_pairs_anddd("abc def,3")
    'cba*fed*'
    >>> flip_consecutive_disjoint_pairs_anddd("abcdefg",4)
    'dcba*'
    >>>flip_consecutive_disjoint_pairs_anddd("abc",1)
    'a*b@c@'
    '''

    if len(s)<= k-1:
        return s

    ns=''

    for i in range(0,len(s)-1,2):
        # i = 0, ...
        block  = block + s[i : i+k]
        rs = block [ : : -1]
       
        if only_vowes == True:
            ns = ns + pair + "*"
        else:
            ns = ns + pair + "@"

    if len(s) % 2 == 1:
        ns = ns + s[-1]

    return ns
    
