#problem:
#given a string s, need to return a new string where
#1. if a character x is non-digit, skip it.
#2. if x is prime, replace it by "pro"
#3. if x is not a prime, then add that digit x  x times.


def messify(s):
    '''
    (str)-> str
    >>>messify("6")
    '666666'
    >>>mesify('12')
    'pr'
    >>>messify('x-y')
    ''
    >>>messify('01234a')
    '1prpr4444'
    '''
    ns=''

    for x in s:
        if x in "0123456789":
            if x in '2357':
                ns = ns+"pr"
            else:
                ns = ns + x * int(x)
    
    return ns




#another problem

#problem:
#write a function called BLA, has one parameter a string s and you need to return a new string


def only_vowes(phrase):
    '''
    (str) -> str
    returns a new string containing all the voes the given string
    >>> only_vowes("August")
    'Auu'
    >>> count_vowes("smrt")
    ''
    '''
    vowels = ""
    for x in phrase:
        if x in 'aeiouAEIOU':
            vowels += x

    return vowels



def flip_consecutive_disjoint_pairs_anddd(s):
    '''
    (str) -> str
    >>>flip_consecutive_disjoint_pairs_anddd("abcdef")
    'ba*dc@fe*
    >>> flip_consecutive_disjoint_pairs_anddd("abcdefg")
    'ba*dc@fe*g'
    >>>flip_consecutive_disjoint_pairs_anddd("g")
    'g'
    '''

    if len(s)<= 1:
        return s

    ns=''

    for i in range(0,len(s)-1,2):
        # i = 0, ...
        pair = s[i+1] + s[i]
        if only_vowes == True:
            ns = ns + pair + "*"
        else:
            ns = ns + pair + "@"

    return ns
    
