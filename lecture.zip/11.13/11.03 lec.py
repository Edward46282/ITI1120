#unordered list n elements
add 0(i)
remove O(n)
search O(n)
#sorted list n elements
add O(n)
remove O(n)
search O(log n)
successor/predessor O(log n)
#set n elements
add O(1)
remove O(1)
search O(1)
successor/predessor O(n)


def palindrom(words): #Assume that words has n words #if the reversed word is same as the word itself
    pal = [] #1
    for word in words: #1*n
        if word = word[::-1]: #O(1)*n #if the word has 45 length, (45+45)*n #O(1) means it is absolute constant.
            pal.append(word)#<=n
    return pal #=1

# 1+n+150*n+n +1 = O(n)
def ananim(words): #if reversed word is a word that is in the dictionary(wordlist)
    ana = [] #1
    for word is words: #1*n
        if word[::-1] in words: #n*n = n^2
            ana.append(word) #<= n

    return ana #<= 1

#updated version using a set
def ananim(words): #if reversed word is a word that is in the dictionary(wordlist)
    ana = [] #1
    words = set(words)
    for word is words: #1*n
        if word[::-1] in words: #1*n = n
            ana.append(word) #<= n

    return ana #<= 1
