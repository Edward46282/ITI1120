m = []
m.append([1,1,1,1,1,1,1,1])

#multiple rows
m = []
for i in range(10):
    row= [1]*10
    m.append(row) #important* It seperates in the list after the loop ends.

print(m)

#multiple matrix
m = []
for i in range(10):
    row= [1]*10
    m.append(row)
    
for row in m:
    for number in row: #it chooses '1'
        print(number, end = " ") #the new line starts as print in default, causes the new line
    print()


#A function that judge whether it is a diagonal matrix or not
def is_diagonal(m):
    '''
    (list of int)-> bool
    Think process=>
    1. is m a square matrix?
    2. Is every element off of diagonal zero?
    '''

    #1 in thinking process
    for i in range(len(m)): #Important: m[i] is a row
        row = m[i]
        if len(m[i]) != len(m): #remember that len(m) is row. and len(m[i]) is a width. Therefore, it tests whether it is square or not.
            return False

    #2 in thinking process

    for i in range(len(m)):
        for j in range(len(m)): #in the matrix, you are generating a coordinate in the loop 
            if m[i][j] != 0 and i != j: #if it is a square list, the coordinate of nonzero will be symmytrical => (0,0) , (1,1), (2,2) are nonzero, other than that, all the numbers are zero.
                return False

    return True



def frequency(a):
    f=[] # a list that I will count the number of cities and occurance
    for i in range(len(a)):  #collecting cities in a loop
        city = a[i]
        flag = False
            
        for j in range(len(f)): #First iteration, this = pass
            #In second, Paris, f only has Mostar.
            #In third iteration, city is Mostar, and f has Mostar and Paris.
            if city == f[j][0]:#
                f[j][1] += 1
                flag = True
        #i should remember did i find the city or not
        if flag == False: #First iteration, it always works.
            f.append([city,1])

       
    return f
        

cities = ["Mostar", "Paris", "Mostar" , "Paris", "Melbourne","Ottawa","Budapest", "NYC", "Melbourne"]
freq = frequency(cities)
print(freq)


#["Mostar", 2],["Paris",2],["Melbourne",3],["Ottawa",1],["NYC",1],["Budapest",1]

#Stradegy to build this function: f.append(["Mostar",1])
