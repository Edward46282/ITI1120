def summer(a):
    if len(a) == 1:
        return a[0]
    elif len(a) == 0:
        return 0

    return summer(a[:len(a)//2]) + summer(a[len(a)//2:])

summer([2,10,7,20])

def power_set(L):
    '''
    (list of int) -> 2D list
    >>>power_set([1,2])
    [ [], [1], [2], [1,2] ]
    '''
          
    if len(L) == 0:
            return [ [] ]
    if len(L) == 1:
            return [ [], [L[0]] ]

    pps = power_set(L[1:])

    fps = pps[:]

    for item in pps:
        fps.append(item + [L[0]])

    return fps

#not fair distribution of work in the last line
def mypow(x, n):
    '''
    (number,int) -> number
    preconditions: x is not zero and n is a positive integer '''

    if n == 0:
        return 1
    elif n == 1:
        return x
    return x * mypow(x, n-1)

#even work ver.
def mypow(x, n):
    '''
    (number,int) -> number
    preconditions: x is not zero and n is a positive integer '''

    if n == 0:
        return 1
    elif n == 1:
        return x
    tmp = mypow(x,n//2)
    if n % 2 == 0:
        return tmp * tmp
    else:
        return x * tmp * tmp
    
