import random

def ask_question(q):
    print()
    print("Category is: ",q[5])
    print("Difficulty is: ",q[-1])
    print(q[0])
    for i in range(1,5):
        print(i,q[i])

def get_answer_raw():
    try:
        ans = int(input("Answer (1,2,3, or 4):  "))
        return ans
    except:
        print("Error. Please Enter an integer")

def get_answer():
    ans = get_answer_raw()
    while ans not in [1,2,3,4]:
        print("Error","Try again")
        ans = get_answer_raw()
    return ans

lines = open("quiz.csv").read().splitlines()

#splitlines split the lines, whereas .split() splits the blank spaces between the letters.

#place 0 is a question, 1-4 answers, 5 is category, 6 is difficulty
questions = []
for line in lines:  #2d list from last lec -> review
    #line is one question, one string
    question = line.split("\t")
    questions.append(question)

lives = 5
score = 0

while lives > 0:
    q = random.choice(questions)
    ask_question(q)
    ans = get_answer()

    p = [1,2,3,4]
    random.shuffle(p)

    if p[ans-1] == 1:
        print("Correct")
        score = score + int(q[-1])
    else:
        print("incorrect. The correct answer is", q[1])
        lives = lives - 1
