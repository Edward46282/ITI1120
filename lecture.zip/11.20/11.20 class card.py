class Card:
    def __init__(self, rank, suit):
        self.rank = rank
        self.suit = suit

    def getRank(self):
        return self.rank

    def getSuit(self):
        return self.suit

    def __repr__(self):
        return 'Card(' +self.rank+','+ self.suit+')'

    def __eq__(self,other):
        return self.rank==other.rank

import random

class Deck:
    def __init__(self):
        self.deck = []
        for rank in Deck.ranks: #ranks and suits are not in the local variable. It is inside of the class. Therefore, I need to add Deck.ranks
            for suit in Deck.suits:
                #rank, suit
                self.deck.append(Card(rank+suit))

    def shuffle(self):
        random.shuffle(self.deck)

    def deal_card(self):
        return self.deck.pop()

    def __len__(self):
        return len(self.deck)
