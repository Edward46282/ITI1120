class Point:
    '''class that represents a point in the plane'''

## calling constructor Point(2,3) does the following
## 1. creates an object of type Point
## 2. produces an object's memory address
## 3. calls an object's __init__ method
## (and stores object's memory address in the
##   first parameter of __init__, i.e. in variable self)

## Assigning to a new variable using dot operator
## CREATES THAT VARIABLE INSIDE OF THE OBJECT

## Variables INSIDE of an object are called INSTANCE variables

## __init__ is method that is called to initialize the object (i.e. initialize its variables)
## the first parameter of method is usually called self
## self refers to the object that is being initialized

#Use dir(POint) to get all the calls for this class
#    constructor
#    notice two underscores
    def __init__(self, xcoord=0, ycoord=1):
        ''' (Point, float, float) -> None
        >>> p=Point(2,3)
        >>> p.x
        >>> 2
        >>> p.y
        >>> 3
        initialize point coordinates to (xcoord, ycoord)'''

        self.x = xcoord
        self.y = ycoord

    def move(self, dx, dy):
        '''(Point,float,float)->None
        change the x and y coordinates by dx and dy'''
        self.x += dx
        self.y += dy

    def get(self):
        return (self.x,self.y)

    def setx(self,xcoord):
        self.x=xcoord

    def sety(self,ycoord):
        self.y=ycoord

    def __eq__(p1,p2): #I am changing existing call
        return p1.x == p2.x and p1.y == p2.y

    def __repr__(self):
        return "Point(" + str(self.x) + "," + str(self.y) + ")"

    def __str__(self): #when I type print-> it first finds __str__. If it can't find it, it then looks for the __repr__
        return "I am a point with the following x and y coord: (" + str(self.x) + "," + str(self.y) + "}"

 
