def silly_printer(n): #counting down 
    print(n)
    silly_printer(n-1)

def silly_printer_iter(n): #without recursion. It doesn't crash because it doesn't create stacks every time it requires n-1.
    while True:
        print(n)
        n = n-1


def silly_printer(n): #for this function, the number of stacks is 5 
    if n == 0:
        print("Blastoff")
    else:
        print(n)
        silly_printer(n-1)

silly_printer(4)


def fact(n): #factorial computing function. It more similer to use recursion than loop because n! = n * (n-1)!
    if n == 0:
        return 1
    else:
        res = n * fact(n-1) # I use return because I need to use the value in the equatoin. Therefore, I can't use print 
        return res

def summation(l):
    if len(l) == 0:
        return 0
    elif len(l) == 1:
        return l[0]
    else:
        return l[0] + summation(l[1:])


def summation(l):
    if len(l) == 0:
        return 0
    elif len(l) == 1:
        return l[0]
    else:
        return summation(l[:len(l)//2]) + summation(l[len(l)//2: ])



