import random

l = list(range(1,1000001))
print(l[:100])

print('\nseperate\n')
k = random.sample(range(1,1000001),1000) # picks random sample
#sample returns a *list of integers* and random. randint returns an *int*
print(k[:100])


def linear_search(L, v): 
    '''
    (list, object) -> int
    '''
    n = len(L) #1
    for i in range(n): # 1*n
        if L[i] == v: # 1*n
            return i #<== 1
    return False #<=== 1

#<= 2n + 2 = O(n)

# in idle->
import random
l = random.sample(range(1,100000),1000)
linear_search(l,50)
False


def binary_search(L,v):
    '''
    (list,object) -> int
    It selects the middle number. If v is larger than that, it omits the first half, including middle.
    If there's no v in L, b should be larger than e. Therefore, while loop condiition is that.
    precondiiton: L is sorted
    '''
    b = 0
    e = len(L)-1
    mid = (b+e)//2 # Finding average will give the mid point
    # b is the beginning and e is the ending point

    while b <= e:
        if v < L[mid]:
            e = mid -1
        elif v > L[mid]:
            b = mid + 1
        else:
            return mid
    return False
