class Mystr(str):
    def first_last_same(self):
        return self[0] == self[-1]
'''
s=str("today) won't work. Therefore, in shortcut: following example
'''

class str(str):
    def first_last_same(self):
        return self[0] == self[-1]


#example with super() function
class Mammal(object):
  def __init__(self, mammalName):
    print(mammalName, 'is a warm-blooded animal.')
    
class Dog(Mammal):
  def __init__(self):
    print('Dog has four legs.')
    super().__init__('Dog') #without this, it will only print(dog has four legs)
    #Therefore, super() allows us to execute class Mammal
    
d1 = Dog()
