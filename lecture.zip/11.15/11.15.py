#Example 1
class Point:
    #1 creates an object of type Point and remembers the address
    #2 looks for init function inside of that class and runs if it finds it
    #3 In order to run it, it assigns the address (from  step 1_ to parameter 'self'
    def __init__(self, xcoor,ycoor): #when you run the program, and type Point(x,y), it __init__ replaces it to Point(x,y) #'self' is just an variable. It just assigns the x and y values
        self.x = xcoor
        self.y = ycoor
        #return p => it doesn't actually displays the 'p', but it returns the address 'p' in backend

p = Point(2,3)
q = Point(3.5, 20)


#Example 2
class Point:
    #1 creates an object of type Point and remembers the address
    #2 looks for init function inside of that class and runs if it finds it
    #3 In order to run it, it assigns the address (from  step 1_ to parameter 'self'
    def __init__(self, xcoor= 0,ycoor = 0): #if there is no self, by default, it returns (0,0)
        self.x = xcoor
        self.y = ycoor
        #return p => it doesn't actually displays the 'p', but it returns the address 'p' in backend

    def move(self, dx,dy):
        self.x = self.x + dx
        self.y = self.y + dy

