for i in range(10,0,-1):
    print(i)




i=10

while i>10:
    print(i)
    i-i-1

    
while i>0:
    print(i) #loops infinitely


l=[10,-10,3]
for item in l:
    print(item)



answer = input("yes or no, whould you like to buy the ticket").strip().lower()

while answer != "yes" and answer!="no":   #Do not get what you want
    print("Incorrect input")
    answer = input ("yes or no, would you like to buy the ticket?")


answer = input("yes or no, whould you like to buy the ticket").strip().lower()

while not(answer == "yes" and answer=="no"):   #Do not get what you want
    print("Incorrect input")
    answer = input ("yes or no, would you like to buy the ticket?")


#Correct example of while loop

s='tqtsmart'

i=0
while s[i] not in "aeiouAEIOU":
    print(s[i])
    i=i+1

#incorrect version

s='smrt'

i=0
while s[i] not in "aeiouAEIOU":
    print(s[i])
    i=i+1
#Fixing incorrect


s='smrt'

i=0
while i<len(s) and s[i] not in "aeiouAEIOU":  #The order of the condition matters if s='' because s[0] = None. Therefore, it crashes.
                                                # False and any other bool expression is always False. So, if the first condiiton is False, python won't execute second condition.
    print(s[i])
    i=i+1


#Another example https://en.wikipedia.org/wiki/Collatz_conjecture

#if number is even, divide it by 2
#Otherwise, 3n+1

#>>>12,6,3,10,5,16,8,4,2,1


def collatz(n):

    while n > 1:
        if n%2 == 0:
            n=n//2
        else:
            n= 3*n+1

    return True

for i in range(1,1000001):
    collatz(i)
print("all first million number satisify collatz conjecture")

#guessing game

import random
def guessing_game():
    x = random.randint(1,1000)
    

    tries = 5
    guess = 1001
    
    while tries > 0 and guess != x:
        guess = int(input("Try and guess: "))
        if guess < x:
            print("Wrong, Too low.")

        elif guess > x:
            print("Wrong. Too high.")
        else:
            print("Great work, You win")
        tries = tries - 1


guessing_game()
