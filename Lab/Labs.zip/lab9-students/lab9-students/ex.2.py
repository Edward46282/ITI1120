def min_or_max_index(m,n):
    minimum = 5000
    maximum = 0
    for i in range(len(m)):
        if m[i] > minimum:
            maximum = m[i]
        if m[i] < minimum:
            minimum = m[i]

    if n == True:
        return maximum
    elif n == False:
        return minimum
