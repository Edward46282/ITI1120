def first_one(L):
    b = 0
    e = len(L)-1
    while b <= e:
        mid = b+e//2
        if 1 in L[b:mid]:
            e = mid - 1
        elif 1 in L[mid:e]:
            b = mid
        if L[mid] == 1 and 1 not in L[b:mid]:
            return mid
    return -1
