# what does this print?

for i in range(5,0,-1):
     num=1
     for j in range (1,i+1):
          print(num, end="| ")
          num=num*2
     print()

     



#ex 1


def ah(l,x,y):
    '''
    (list, int, int) -> (int,int)
    The function returns the number of elements of l that are between x and y and it also returns minimum element of l that is between x and y
    '''
    count = 0
    
    for k in l:
        if x <= k <= y:
            count += 1
    l.sort()
    for m in l:
        if m > x:
            return (count, m)

            
#ex 2

def is_perfect(m):
    '''
    (int) -> bool
    The function prints all factors of the input integer, and determines if it is a perfect number or not
    '''
    counter = []
    for k in range(1, m):
        if int(m)% k == 0:
            counter.append(k)
    print (counter)

    if sum(counter) == m:
        return True
    else:
        return False


#ex 3a


def arithmetic(m):
    '''
    (list) -> bool
    This function determines whether the list is ina from of arithmetic progression.
    '''
    diff = m[2] - m[1]
    for k in range(1,len(m)):
        if m[k] - m[k-1] == diff:
            s = True
        else:
            s = False
            break

    return s


#ex3b
def is_sorted(m):
    '''
    (list) -> bool
    The function determines whether the list is sorted from least to greatest or not
    '''
    for k in range(1,len(m)):
        if m[k] >= m[k-1]:
            s = True
        else:
            s = False
            break

    return s
