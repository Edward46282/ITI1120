def gcd(a,b):
    global n
    if a%2 == 0 and b%2 == 0:
        n = n*2
        gcd(a/2, b/2)
    return n
n=1
