#exercise 1
def m(i):
    if i == 1:
        return 1/3
    else:
        return (i/(2*i+1)) + m(i-1)


#ex 2

def count_digits(n):
    if n == 0 or n < 10:
        return 1
    else:
        return 1 + count_digits((n-1)//10)

#ex3

def is_palindrome(word):
    word = word.lower()
    if len(word) < 2:
        return True
    if word[0] != word[-1]:
        return False
    return is_palindrome(word[1:-1])

#ex4
def is_palindrome_v2(word):
    word = word.lower()
    if len(word) < 2:
            return True
    if word[0].isalpha() == False:
        return is_palindrome_v2(word[1:])
    if word[-1].isalpha() == False:
        return is_palindrome_v2(word[:-1])
    else:
        if len(word) < 2:
            return True
        if word[0] != word[-1]:
            return False
        return is_palindrome_v2(word[1:-1])

#ex5
def gcd(a,b):
    global n
    if a%2 == 0 and b%2 == 0:
        n = n*2
        gcd(a/2, b/2)
    return n
n=1

