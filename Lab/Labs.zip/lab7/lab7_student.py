#5.16
def indexes(word,letter):
    display = []
    for i in range(len(word)):
        if word[i] == letter:
            display.append(i)
    return display


#5.17
def doubles(l):
    empt = []
    blank = ''
    for k in range(len(l)-1):
        if l[k+1] == l[k]*2:
            empt.append(k)
    for element in empt:
        blank = blank + str(element) + '\n'

    print( blank)

#5.18
def four_letter(n):
    empt = []
    for i in range(len(n)):
        if len(n[i]) == 4:
            empt.append(n[i])

    return empt

#5.19
def inBoth(li,secnd):
    for h in range(len(li)):
        if li[h] in secnd:
            return True
    return False

#5.20
def intersect(first,second):
    listing = []
    for h in range(len(first)):
        if first[h] in second:
            listing.append(first[h])
    return listing

#5.21

def pair(lm,kl,h):
    for i in range(len(lm)):
        for k in range(len(kl)):
            if lm[i] + kl[k] == h:
                print(str(lm[i]) + ' ' +  str(kl[k]))


#5.22

def pairSum(n,h):
    for i in range(len(n)):
        for k in range(i+1,len(n)):
            if n[i] + n[k] == h:
                print(str(i),str(k))

#5.29

def lastfirst(n):
    firstname = []
    lastname = []
    for i in range(len(n)):
        make_li = n[i].split(',')
        lastname.append(make_li[1][1:])
        firstname.append(make_li[0])
        

    return (lastname,firstname)

#5.31

def subsetSum(k,target):
    for i in range(len(k)):
        for h in range(i+1,len(k)):
            for t in range(h+1,len(k)):
                if k[i] + k[h] + k[t] == target:
                    return True
    return False

#5.33

def mystery(n):
    i=0
    while n > 1:
        n = n//2
        i += 1
    return i

#5.46
def inversion(n):
    



#5.48
def sublist(k,t):
    addi = []
    for i in k:
        if i in t:
            x = t.index(i)
            addi.append(x)

    for m in range(len(addi)-1):
        if addi[m] > addi[m+1]:
            return False
    return True

               
