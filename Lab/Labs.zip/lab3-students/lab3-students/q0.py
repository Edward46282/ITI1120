
############# PART 1 ##############

def info_day(today, weather, temperature):
     print(today, "is a", weather, "day. The temperature is", temperature, "degrees Celsius.")

     #Create a string s below such that print(s) command below
     #prints the exact same message as the above print statement.
     # Once you are done, uncomment the two lines of code below
     #
     #s=
     #print(s)

info_day("Saturday", "nice", 29)
info_day("Monday", "so so", 15)

############# PART 2 #############

# Uncomment the 3-4 lines of code starting with def below.
# Run the program. Why does it crash?
# Can you fix it without chaning function call: letter_grade("B")

#def letter_grade("grade"):
#     print("Your grade is", "grade")
#
#letter_grade("B")

############# PART 3 #############

# Rewrite the following program so that it computes the average
# in a function called average_of_two. 
# Obtaining the input from the user and printing of the result
# must still be outside of the the function.
#
# Make sure to write DOCSTRINGS for your function, including TYPE CONTRACT.
# Test it by running help(average_of_two) in python shell.

x=float(input("Give me 1st number: "))
y=float(input("give me 2nd number: "))

average=(x+y)/2

print("The average of", x, "and", y,"is", average)






#ex 1
def pay(hourly_wage, num_hours):
     '''
     (num, num) -> num

     it calculates the total pay for workers to get 
     '''
    if num_hours <= 40:
        tot = hourly_wage * num_hours

    elif num_hours > 40 and num_hours <= 60:
        tot = (((num_hours - 40) * hourly_wage) * 1.5) + (40*hourly_wage)

    elif num_hours > 60:
        tot = (((num_hours-60) * hourly_wage) * 2 ) + (40 * (hourly_wage)) + (20 * hourly_wage *1.5)
    return tot
        
#ex2
def rps (p1,p2):
     '''
     (str,str) -> int
     precondition: input should be R or P or S
     This function should show who wins the game
     '''
    p1 = p1.upper()
    p2 = p2.upper()
    if 
         return 1
    if p1 == p2:
        return 0
    elif p1 == "R":
        if p2 == "P":
            return 1
        else:
            return -1

    elif p1 == "P":
        if p2 == "S":
            return 1
        else:
            return -1

    elif p1 == "S":
        if p2 == "R":
            return 1
        else:
            return -1
        
#ex3a
def is_divisible(n,m):
     '''
     (int,int) -> bool
     this function finds out whether n is divisible by m
     '''
    return n%m == 0

n= int(input("Enter 1st integer:\n"))
m= int(input("Enter 2nd integer:\n"))
k= is_divisible(n,m)
if k == True:
    print(str(n)+ " is divisible by " + str(m))

else:
    print(str(n)+ " is not divisible by " + str(m))

#ex3b


def is_divisible(n,m):
     '''
     (int,int) -> bool
     '''
    return n%m == 0

def is_divisible23n8(i):
     '''
     (int) -> str
     this function retruns yes if given number is divisiele by 2 or 3, but not 8
     '''
    if (is_divisible(i,2) == True or is_divisible(i,3)== True )and is_divisible (i,8) !=True:
        return "yes"
    else:
        return "no"

i = int(input("Enter a integer: "))
is_divi238 = is_divisible23n8(i)
if is_divi238 == "yes":
    print(str(i) + " is divisible by 2 or 3 but not 8")
else:
    print("It is not true that " + str(i) + " is divisible by 2 or 3 but not 8")
    


    









