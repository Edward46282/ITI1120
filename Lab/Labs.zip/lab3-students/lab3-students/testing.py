def pay(hourly_wage, num_hours):
    '''
     (num, num) -> num

     it calculates the total pay for workers to get 
    '''
    if num_hours <= 40:
        tot = hourly_wage * num_hours

    elif num_hours > 40 and num_hours <= 60:
        tot = (((num_hours - 40) * hourly_wage) * 1.5) + (40*hourly_wage)

    elif num_hours > 60:
        tot = (((num_hours-60) * hourly_wage) * 2 ) + (40 * (hourly_wage)) + (20 * hourly_wage *1.5)
    return tot
