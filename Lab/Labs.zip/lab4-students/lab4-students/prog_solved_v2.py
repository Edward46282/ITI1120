#Q1
def is_eligible(age,citizenship, prison):
     '''
     (int,str,str) -> bool
     '''
     if age >=18 and citizenship.strip() in ("canada", "canadian") and prison == "yes":
          return True

     else:
          return False
     
name=input("What is your name? ")
age= int(input("How old are you? "))
citizenship = input("What citizenship are you having? ")
citizenship = citizenship.lower()
prison = input("Are you currently in prison convicted for a crriminal offence? ")
prison = prison.lower()
if is_eligible(age,citizenship, prison):
     print(name, ", you are eligible to vote")
else:
     print(name, ", you are ineligible to vote") 
    



          
#Q2

def mess(s):
     '''
     (str) -> str
     It adds "-" in spaces, and captialize the consonents
     '''
     emp_str = ""
     for x in s:
        if x in "rstvwxyz":
            x= x.upper()
        elif x == " ":
            x = "-"
        emp_str += str (x)

     return emp_str



#Q3
def is_divisible(n,m):
     '''(int, int)->bool
     returns True if n is divisible by n, and False otherwise.'''
     return n%m==0

def is_divisible23n8(n):
     '''(int)->bool
     returns string "yes" if n is divisible by 2 or 3 but not 8, and "no" otherwise.'''
     if ( (is_divisible(n,2) or is_divisible(n,3)) and not(is_divisible(n,8))):
          return True
     else:
          return False

n= int(input("input a number: "))

for k in range(0,n):
     empt = ""
     re = is_divisible23n8(k)
     if re == True:
          empt += str(k)

     print(empt)



#Q4


k = int(input("Enter a number "))

for i in range (1,k+1):
    print("$" * i)


#Q5


def divisors(k):
    '''
    (int) -> int
    It lists all the divsiors of k
    precondition: k is a positive integer
    
    '''
    empt = []
    for i in range(1, k//2 + 1):
        if k % i == 0:
            empt.append(i)
    empt.append(k)
    return empt


def prime(po):
    '''
    (int) -> none
    It prints if the po is prime number or not
    '''
    if len(divisors(po)) == 2:
        print("It's prime")
    else:
        print("It's not prime")
