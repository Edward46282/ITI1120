def create_books_2Dlist(file_name):
    x = open(file_name).read().splitlines()
    new_list = []
    for info in x:
        info = info.split("\t")
        new_list.append(info)
    print(new_list)
        

def search_by_year(books,year1,year2):
    pass

file_name=input("Enter the name of the file: ")
file_name=file_name.strip()
alc_table=create_books_2Dlist(file_name)
