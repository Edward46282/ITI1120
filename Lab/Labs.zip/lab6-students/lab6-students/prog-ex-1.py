#1
def sum_odd_while_v2(n):
    '''(int)->int
    Returns the sum of all odd integers between 5 and n
    '''
    summ = 0
    i=5
    while i <= n:
        if i%2 != 0:
            summ += i
        i+=1
    return summ


#2
summ = 0
def ex2(n,k):
    summ = int(n) + int(k)
    return summ

status = True


while status == True:
    n = input("Please enter an integer: ")
    k = input("Please enter another integer: ")
    print(ex2(n,k))
    another = input("Would you like to use again? ")
    if another != "yes":
        status = False

#3
def first_neg(n):
    i = 0
    if len(n) == 0:
        return None
    else:
        while i < len(n) and n[i] > 0:
            if n[len(n)-1] > 0:
                return None
            i = i + 1
        return i


#4

def sum_5_consecutive(k):
    i = 0
    ba = False
    if len(k) < 5:
        return False
    else:
        while i <= (len(k)-5):
            if sum(k[i:i+5]) == 0:
                ba = True
            i += 1
        return ba
            

#6

def fib(n):
    i = 2
    emp = [1,1]
    while i < n:
        emp.append(emp[i-2] + emp[i-1])
        i += 1
    print(emp)

#7

def inner_product(n,k):
    i = 0
    coun = 0
    while i<len(n):
        summ  = n[i] * k[i]
        coun = coun + summ
        i+=1
    return coun

