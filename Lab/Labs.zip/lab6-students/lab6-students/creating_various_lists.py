import random
n=int(input("Enter a positive even integer for the size of the list?" ))
#1
a= ([0]*n)
#1b
x = [0]
print( (x*n))

#2
b = ([random.randint(1,100)]*n)

#2b
k = [random.randint(1,100)]
print(k*n)

#3
c = b

#4
d = ([0]*int((n/2))) + b + c

#5
d = b

#6
e = b[2]
