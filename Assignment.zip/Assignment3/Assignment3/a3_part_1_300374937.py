

def is_up_monotone(X, d):
    '''
    (str, str) -> bool
    precondition: the number of digits in X is divisible by the integer represented by d. And they are positive integers.
    It returns True if it's up monotone
    '''
    d = int(d)
    empty_str = ""
    for i in range(0, len(X), d):
        if i == len(X) - d:
            z = X[i:i+d]
            empty_str = empty_str + z
        else:    
            z = X[i:i+d]
            empty_str = empty_str + z + ", "

    print(empty_str)

    previous = 0
    mono = True

    for j in range(0,len(X), d):
        
        if j != "," and j!= " ":
            current_number = int(X[j:j+d])
            if current_number < previous:
                mono = False

            else:
                previous = current_number
    
    return mono



# you can add more function definitions here if you like       


            
print("****************************************")
print("*                                      *")
print("*  __Welcome to up-monotone inquiry__  *")
print("*                                      *")
print("****************************************")
# Your code for the welcome message goes here, instead of name="Vida"
name=input("What is your name?\t")

width_of_the_border = len(name) + 41
print("*"*width_of_the_border)
print("*"+" "*(width_of_the_border-2) + "*")
print("* __" + name +", welcome to up-monotone inquiry.__ *")
print("*"+" "*(width_of_the_border-2) + "*")
print("*"*width_of_the_border)
flag=True
while flag:
    question=input(name+", would you like to test if a number admits an up-monotone split of given size? ")
    question=(question.strip()).lower()
    if question=='no':
        flag=False
    elif question == 'yes':
        print("Good choice!")
        X = input("Enter a positive integer:\t")
        X = X.strip()
        if X.isalpha() == True:
            print("The input can only contain digitis. Try again.")
        elif float(X) <= 0:
            print("The input has to be a positive integer. Try again.")
        elif X.isnumeric() == False:
            print("The input can only contain digits. Try again.")
        
        else:
            d = input("Input the split. The split has to divide the length of " + X + " i.e. " + str(len(X)) + "\n")
            d = d.strip()
            if float(d) <= 0:
                print("The split can only contain digits. Try again.")
            elif len(X)%int(d) != 0:
                print(d + " does not divide " + str(len(X)) + ". Try again.")
            else:
                result = is_up_monotone(X, d)
                if result == True:
                    print("The sequence is up-monotone")
                else:
                    print("The sequence is not up-monotone")
    else:
        print("Please enter yes or no. Try again.")
                  
        
    #YOUR CODE GOES HERE. The next line should be elif or else.
        
#finally your code goes here too.

widthrec = 18 + len(name)

print("*" * widthrec)
print("*" + " " * (widthrec-2) + "*")
print("* __Good bye "+ name + "!__ *")
print("*" + " " * (widthrec-2) + "*")
print("*" * widthrec)
