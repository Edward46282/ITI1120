############
#2.1
############

def sum_odd_divisors(n):
    '''
    (int) -> None or int
    This function returns the sum of all positive odd divisors of the input.
    '''
    if n==0:
        return None
    else:
        emint = 0
        n = abs(n)
        for k in range (1, n+1):
            if n%k == 0:
                if k % 2 != 0:
                    emint = emint + k

        return emint

        
        
##############
#2,2
##############

def series_sum():
    '''
    (int)-> num or None
    precondition: The user needs to input an non-negative integer n.
    The function returns the value based on the given equation.
    '''
    en = input("Please enter a non-negative integer:\t")
    if int(en) < 0:
        return None
    else:
        sum_of_the_eq = 1000
        for h in range(1,int(en)+1):
            series = 1/(h**2)
            sum_of_the_eq += float(series)
        return sum_of_the_eq
            
##########
#2.3
##########


def pell(n):
    '''
    (int)-> None or int
    If user inputs negative number, it returns None. If the user inputs a positive integer, it returns the nth Pell number.
    '''
    if n < 0:
        return None
    else:
        Seco_prev_num = 1
        previous_num = 2
        if n == 0:
            return 0
        elif n == 1:
            return 1
        elif n == 2:
            return 2
        else:
            for h in range (3,n+1):
                now = 2*previous_num + Seco_prev_num
                Seco_prev_num = previous_num
                previous_num = now
            return now


#########
#2.4
#########

def countMembers(s):
    '''
    (str)-> int
    The function returns the number of characters in s, that are extraordinary.
    '''
    counter = 0
    lim = "23456efghijFGHIJKLMNOPQRSTUVWX!,\\"
    for i in s:
        if i in lim:
            counter += 1

    return counter


########
#2.5
#########

def casual_number(s):
    '''
    (str) -> None or int
    precondition: The user doesn't put the commas in wrong place like ’1, 1, 345’
    This function returns None if the input does not look like a number. If it looks like a number, it returns the number without commas
    '''
    tota = ""
    tota_se = ""
    usein = s
    if "-" in s:
        usein = s[1:]
    for i in usein:
        if i != ",":
            tota += i
    for k in s:
        if k != ",":
            tota_se += k

    if tota.isnumeric() == True and tota_se.startswith("-") == True:
        return tota_se
    elif tota.isnumeric() == True:
        return tota
    else:
        return None




##########
#2.6 and 2.7
##########

def alienNumbers(s):
    '''
    (str)-> int
    precondition: The user doesn't input a symbol that is not in the given table
    This function takes one parameter, and returns the integer value represented by s. 
    '''
    acc = 0
    for i in s:
        if i == 'T':
            acc += 1024
        elif i == 'y':
            acc += 598
        elif i == '!':
            acc += 121
        elif i == 'a':
            acc += 42
        elif i == 'N':
            acc += 6
        elif i == 'U':
            acc += 1

    return acc


#############
#2.8
###########
def encrypt(s):
    '''
    (str) -> str
    This function returns the ecrypted code, which is based on the input. 
    '''
    empt = ""
    rev = s[::-1]
    if len(rev)%2 != 0:
        for i in range(0,len(rev)//2):
            empt = empt + rev[i] + rev[len(rev)-i-1]
        empt += rev[len(rev)//2 ]

                                   
    else:
        for i in range(0,len(rev)//2):
            empt = empt + rev[i] + rev[len(rev)-i-1]
    
    return empt


#########
#2.9
#########

def weaveop(s):
    '''
    (str) -> str
    This function returns a string that inserts letter o,p,O,P between the letters in specific condition. 
    '''

    newS = s[0]
    leng = len(s)
    
    for i in range(0, leng-1):

        if ((s[i].isalpha() == True) and (s[i+1].isalpha() == True)):
            if (s[i].isupper() == True):
                newS = newS + "O"
            elif (s[i].islower()):
                newS = newS + "o"
               
                
                
            if (s[i+1].isupper() == True):
                newS = newS + "P"
            elif (s[i+1].islower()):
                newS = newS + "p"
        
        
        newS = newS + s[i+1]

    
    return newS

###########
#2.10
##########

def squarefree(s):
    '''
    (str) -> bool
    The function returns True if the input is squarefree. 
    '''
    length_of_the_word = len(s)
    ma = length_of_the_word //2 +1
    for i in range(1, ma):
        s1 = s[:i]
        if s1 in s[i:]:
            return False
    return True

